export interface IMySelector {
    open: boolean;
}
