export interface IMyDefaultMonth {
    defMonth: string;
}
