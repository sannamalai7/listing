import { IMyDate } from "./my-date.interface";

export interface IMyDateRange {
    begin: IMyDate;
    end: IMyDate;
}
