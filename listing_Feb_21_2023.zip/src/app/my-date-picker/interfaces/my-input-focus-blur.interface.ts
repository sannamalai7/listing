export interface IMyInputFocusBlur {
    reason: number;
    value: string;
}
